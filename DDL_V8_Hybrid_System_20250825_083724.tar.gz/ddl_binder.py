#!/usr/bin/env python3
"""
DDL Evidence Binder (drop‑in replacement)

Highlights
- Robust parquet discovery (recursive), schema normalization, and diagnostics
- Heartbeat/liveness file to distinguish "thinking" vs. "hung"
- Three-tier retrieval (A strict, B relaxed, C semantic-lite) with tier stamps
- Budgeted NLI labeling with short timeouts + lexical fallback
- Reliable paper anchor extraction (exact + fuzzy) with precise citation spans
- Deterministic lexical retrieval scoring + scan cap for speed
- Bound/paper-only/unbound compatible with your three-tier composer
"""

import os
import re
import json
import time
import logging
from typing import Dict, List, Any, Tuple, Optional
import numpy as np

import pandas as pd

# Disable debug logging to match working baseline
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)  # Only warnings and errors

try:
    # If available, we might later use embeddings; keep optional.
    from sentence_transformers import SentenceTransformer  # noqa: F401
    _HAVE_ST = True
except Exception:
    _HAVE_ST = False

# Resource hygiene (prevents HF fork/tokenizer issues)
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import openai  # LM Studio/OpenAI-compatible client


class DDLEvidenceBinder:
    """
    Binds accepted daydreams to supporting quotes from both paper and corpus.
    Two-hop retrieval + NLI labeling + robust fallbacks.
    """

    # ----------- init & corpus loading -----------

    def __init__(self,
                 corpus_path: str,
                 api_base: str = "http://localhost:11434/v1",
                 api_key: str = "ollama",
                 model: str = "qwen3-30b",
                 min_quote_len: int = 50,
                 max_quote_len: int = 120,
                 quotes_per_daydream: int = 3,    # 1 paper + up to 2 corpus
                 max_quotes_total: int = 30,      # global quote budget (used upstream)
                 nli_timeout_s: int = 4,
                 scan_cap: int = 50000):

        self.corpus_path = os.path.abspath(corpus_path)
        self.client = openai.OpenAI(base_url=api_base, api_key=api_key)
        self.model = model

        # Quote constraints
        self.min_quote_length = min_quote_len
        self.max_quote_length = max_quote_len

        # Evidence requirements
        self.quotes_per_daydream = quotes_per_daydream
        self.max_quotes_total = max_quotes_total

        # NLI/throughput knobs
        self.nli_timeout_s = nli_timeout_s
        self.scan_cap = scan_cap  # max rows to scan for lexical retrieval

        # Liveness/telemetry
        self.heartbeat_file = os.path.join(os.getcwd(), "binder.heartbeat.json")
        self.last_heartbeat = 0.0

        # Load/normalize corpus
        self.files_loaded = 0
        self.corpus_df = self._load_corpus()
        
        # Initialize embedding model for semantic similarity (optional)
        # Temporarily disabled for testing - will re-enable after core fixes are verified
        self.embedding_model = None
        logger.debug("Embedding model disabled for testing - using lexical matching only")

    # ----------- filesystem & schema -----------

    def _discover_parquets(self, corpus_path: str) -> List[str]:
        """Discover parquet files recursively or accept a single parquet file."""
        import glob

        if os.path.isdir(corpus_path):
            files = glob.glob(os.path.join(corpus_path, "**", "*.parquet"), recursive=True)
        elif corpus_path.endswith(".parquet"):
            files = [corpus_path]
        else:
            # Try non-recursive same-dir fallback
            corpus_dir = os.path.dirname(corpus_path) if not os.path.isdir(corpus_path) else corpus_path
            files = glob.glob(os.path.join(corpus_dir, "*.parquet"))

        if not files:
            raise FileNotFoundError(
                f"No parquet files found.\n"
                f"  Path: {corpus_path}\n"
                f"  CWD: {os.getcwd()}\n"
                f"  Absolute: {os.path.abspath(corpus_path)}"
            )
        files = sorted(files)
        print(f"✓ Discovered {len(files)} parquet files")
        return files

    def _normalize_df(self, df: pd.DataFrame, file_path: str = "unknown") -> pd.DataFrame:
        """Normalize to a consistent schema: doc_id, author, year, title, text."""
        COLUMN_MAPPING = {
            "content": "text",
            "body": "text",
            "chunk": "text",
            "span_text": "text",
            "authors": "author",
            "doc_title": "title",
            "source_title": "title",
        }
        for old, new in COLUMN_MAPPING.items():
            if old in df.columns and new not in df.columns:
                df = df.rename(columns={old: new})

        # doc_id
        if "doc_id" not in df.columns:
            if "source_id" in df.columns:
                df["doc_id"] = df["source_id"].astype(str)
            else:
                df["doc_id"] = "unknown_" + df.index.astype(str)

        # author
        if "author" not in df.columns:
            df["author"] = "Unknown"

        # year
        if "year" not in df.columns:
            if "pub_date" in df.columns:
                try:
                    df["year"] = pd.to_datetime(df["pub_date"], errors="coerce").dt.year.fillna(2020).astype(int)
                except Exception:
                    df["year"] = 2020
            else:
                df["year"] = 2020

        # title
        if "title" not in df.columns:
            df["title"] = "Untitled"

        # text
        if "text" not in df.columns:
            print(f"Warning: No text-like column in {file_path}, creating empty 'text'")
            df["text"] = ""

        # Ensure string types & no NaNs
        for col in ["doc_id", "author", "title", "text"]:
            if col in df.columns:
                df[col] = df[col].astype(str).fillna("")

        # Sample schema audit
        if len(df) >= 5:
            sample = df[["doc_id", "author", "year", "title", "text"]].head(5)
            print(f"✓ Schema sample from {file_path}:")
            for idx, row in sample.iterrows():
                preview = row["text"][:60].replace("\n", " ")
                if len(row["text"]) > 60:
                    preview += "..."
                print(f"  [{idx}] {row['doc_id']} | {row['author']} | {row['year']} | {row['title'][:32]}... | '{preview}'")

        # Empty text ratio
        empty_ratio = (df["text"].str.len() == 0).mean() if len(df) else 1.0
        if empty_ratio > 0.30:
            msg = f"⚠️  High empty-text ratio {empty_ratio:.1%} in {file_path}"
            print(msg)
            try:
                with open("binder.skipped.txt", "a", encoding="utf-8") as f:
                    f.write(f"{file_path}: empty_text_ratio={empty_ratio:.1%}\n")
            except Exception:
                pass
        return df

    def _load_corpus(self) -> pd.DataFrame:
        """Load and normalize corpus parquets (capped for memory)."""
        try:
            if self.corpus_path.endswith(".parquet"):
                df = pd.read_parquet(self.corpus_path)
                df = self._normalize_df(df, self.corpus_path)
                self.files_loaded = 1
                print(f"Loaded corpus with {len(df)} chunks after normalization")
                return df

            files = self._discover_parquets(self.corpus_path)
            dfs, loaded = [], 0
            # Load up to 50 files using strided sampling for diverse coverage
            max_files = min(50, len(files))
            selected_files = self._sample_parquet_files(files, max_files, "strided")
            print(f"Loading {max_files} of {len(files)} parquet files (strided sampling)...")
            for i, fp in enumerate(selected_files):
                try:
                    chunk = pd.read_parquet(fp)
                    chunk = self._normalize_df(chunk, fp)
                    dfs.append(chunk)
                    loaded += 1
                    if (i + 1) % 10 == 0:
                        print(f"  Loaded {i+1}/{max_files} files...")
                except Exception as e:
                    print(f"  Failed to load {fp}: {e}")

            self.files_loaded = loaded
            if dfs:
                df = pd.concat(dfs, ignore_index=True)
                print(f"Loaded corpus with {len(df)} total chunks (files_loaded={self.files_loaded})")
                return df
            print("Warning: no parquet files successfully loaded")
            return pd.DataFrame()
        except Exception as e:
            print(f"Error loading corpus: {e}")
            return pd.DataFrame()
    
    def _sample_parquet_files(self, files: List[str], limit: int = 50, mode: str = "strided") -> List[str]:
        """Sample parquet files using different strategies to avoid topic bias."""
        if len(files) <= limit:
            return files
        
        if mode == "strided":
            # Deterministic strided sampling for full coverage
            step = max(1, len(files) // limit)
            indices = list(range(0, len(files), step))[:limit]
            return [files[i] for i in indices]
        elif mode == "random":
            # Random sampling (for future use)
            import random
            return random.sample(files, limit)
        else:
            # Default: first N files (original behavior)
            return files[:limit]

    # ----------- public API used by pipeline -----------

    def bind_evidence(self, accepted_daydreams: List[Dict[str, Any]], paper_text: str) -> List[Dict[str, Any]]:
        """Bind (paper + corpus) evidence to accepted daydreams."""
        bound, total_quotes = [], 0
        print(f"Binding evidence for {len(accepted_daydreams)} daydreams...")

        for i, d in enumerate(accepted_daydreams):
            self._update_heartbeat(i, "binding", len(bound))
            if total_quotes >= self.max_quotes_total:
                print(f"Reached quote budget ({self.max_quotes_total})")
                break

            ev = self._bind_single_daydream(d, paper_text)
            if self._has_required_evidence(ev):
                d2 = dict(d)
                d2["evidence"] = ev
                d2["theme_hint"] = self._generate_theme_hint(d)
                bound.append(d2)
                total_quotes += len(ev)
            else:
                print(f"Insufficient evidence for daydream {i+1}")

        print(f"Successfully bound evidence for {len(bound)} daydreams")
        print(f"Total quotes used: {total_quotes}/{self.max_quotes_total}")
        return bound

    def save_bound_daydreams(self, bound_daydreams: List[Dict[str, Any]], output_path: str):
        with open(output_path, "w", encoding="utf-8") as f:
            for d in bound_daydreams:
                f.write(json.dumps(d) + "\n")

    def get_binding_statistics(self, bound_daydreams: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not bound_daydreams:
            return {}
        total_evidence = sum(len(d.get("evidence", [])) for d in bound_daydreams)
        paper_q = sum(sum(1 for e in d.get("evidence", []) if e.get("source") == "paper") for d in bound_daydreams)
        corpus_q = sum(sum(1 for e in d.get("evidence", []) if e.get("source") == "corpus") for d in bound_daydreams)
        supports = sum(sum(1 for e in d.get("evidence", []) if e.get("label") == "supports") for d in bound_daydreams)
        contradicts = sum(sum(1 for e in d.get("evidence", []) if e.get("label") == "contradicts") for d in bound_daydreams)

        return {
            "bound_daydreams": len(bound_daydreams),
            "total_evidence": total_evidence,
            "paper_quotes": paper_q,
            "corpus_quotes": corpus_q,
            "supports": supports,
            "contradicts": contradicts,
            "avg_evidence_per_daydream": total_evidence / max(1, len(bound_daydreams)),
        }

    # ----------- core binding -----------

    def _bind_single_daydream(self, daydream: Dict[str, Any], paper_text: str) -> List[Dict[str, Any]]:
        evidence: List[Dict[str, Any]] = []

        # Paper quote (exact or fuzzy)
        pq = self._get_paper_anchor_quote(daydream, paper_text)
        if pq:
            evidence.append(pq)

        # Corpus quotes via 3-tier retrieval
        cq = self._get_corpus_quotes(daydream, max_quotes=2)
        evidence.extend(cq)

        return evidence

    # ----------- paper anchor extraction -----------

    def _get_paper_anchor_quote(self, daydream: Dict[str, Any], paper_text: str) -> Optional[Dict[str, Any]]:
        anchor = (daydream.get("paper_anchor") or "").strip()
        concept = (daydream.get("paper_concept") or "").strip()

        if not anchor and not concept:
            return None

        low = paper_text.lower()
        if anchor and anchor.lower() in low:
            start = low.index(anchor.lower())
            q = self._extract_quote_window(paper_text, start, target_words=80)
            if q:
                return {
                    "source": "paper",
                    "label": "supports",
                    "citation": f"(paper@{q['char_start']}-{q['char_end']})",
                    "quote": q["quote"],
                }

        # Fuzzy fallback: best matching sentence to (anchor or concept)
        sentences = self._split_into_sentences(paper_text)
        if not sentences:
            return None

        key = (anchor or concept).lower()
        from difflib import SequenceMatcher
        best_i, best_score = -1, 0.0
        for i, s in enumerate(sentences):
            sc = SequenceMatcher(None, key, s.lower()).ratio()
            if sc > best_score:
                best_score, best_i = sc, i

        if best_score >= 0.55:
            # compute char start
            char_start = 0
            for j, s in enumerate(sentences):
                if j == best_i:
                    break
                # +1 rough separator
                char_start += len(s) + 1
            q = self._extract_quote_window(paper_text, char_start, target_words=80)
            if q:
                return {
                    "source": "paper",
                    "label": "supports",
                    "citation": f"(paper@{q['char_start']}-{q['char_end']})",
                    "quote": q["quote"],
                }
        return None

    def _extract_quote_window(self, text: str, char_start: int, target_words: int = 80) -> Optional[Dict[str, str]]:
        words = re.findall(r"\b\w+\b", text)
        # Build indices of word starts
        word_starts, pos = [], 0
        for w in words:
            wp = text.find(w, pos)
            word_starts.append(wp)
            pos = wp + len(w)

        # Find which word char_start lands in
        start_word_idx = 0
        for i, wp in enumerate(word_starts):
            if wp <= char_start:
                start_word_idx = i
            else:
                break

        half = target_words // 2
        si = max(0, start_word_idx - half)
        ei = min(len(words), start_word_idx + half)

        if si >= ei:
            return None

        start_char = word_starts[si] if si < len(word_starts) else 0
        end_char = (word_starts[ei] if ei < len(word_starts) else word_starts[-1] + len(words[-1]))
        quote = text[start_char:end_char].strip()

        if self.min_quote_length <= len(quote) <= self.max_quote_length * 2:
            return {"quote": quote, "char_start": start_char, "char_end": end_char}
        return None

    # ----------- retrieval tiers -----------

    def _get_corpus_quotes(self, daydream: Dict[str, Any], max_quotes: int = 2) -> List[Dict[str, Any]]:
        if self.corpus_df.empty:
            return []

        paper_concept = (daydream.get("paper_concept") or "").strip()
        corpus_concept = (daydream.get("corpus_concept") or "").strip()
        hypothesis = (daydream.get("hypothesis") or "").strip()

        quotes: List[Dict[str, Any]] = []
        stats = {"tierA": 0, "tierB": 0, "tierC": 0, "supports": 0, "contradicts": 0, "neutrals": 0, "nli_fails": 0}

        # Tier A: strict (both concepts present)
        tier_a = self._retrieve_tier_a(paper_concept, corpus_concept, hypothesis, k=120)
        for c in tier_a:
            c["retrieval_tier"] = "A"
        stats["tierA"] = len(tier_a)
        if tier_a:
            labeled_a, _ = self._nli_batch_label_with_budget(tier_a, hypothesis, timeout_s=self.nli_timeout_s)
            quotes.extend([q for q in labeled_a if q["label"] in ("supports", "contradicts")])
            self._update_nli_stats(labeled_a, stats)
            if len(quotes) >= max_quotes:
                self._log_binding_stats(**stats)
                return quotes[:max_quotes]

        # Tier B: relaxed (one concept + hint from hypothesis head)
        if len(quotes) < max_quotes:
            tier_b = self._retrieve_tier_b(paper_concept, corpus_concept, hypothesis, k=200)
            for c in tier_b:
                c["retrieval_tier"] = "B"
            stats["tierB"] = len(tier_b)
            if tier_b:
                labeled_b, _ = self._nli_batch_label_with_budget(tier_b, hypothesis, timeout_s=self.nli_timeout_s)
                quotes.extend([q for q in labeled_b if q["label"] in ("supports", "contradicts")])
                self._update_nli_stats(labeled_b, stats)
                if len(quotes) >= max_quotes:
                    self._log_binding_stats(**stats)
                    return quotes[:max_quotes]

        # Tier C: semantic-lite (lexical overlap only; mark as weak)
        if len(quotes) < max_quotes:
            tier_c = self._retrieve_tier_c(paper_concept, corpus_concept, hypothesis, k=300)
            for c in tier_c:
                c["retrieval_tier"] = "C"
            stats["tierC"] = len(tier_c)
            if tier_c:
                labeled_c, _ = self._nli_batch_label_with_budget(tier_c, hypothesis, timeout_s=self.nli_timeout_s)
                for q in labeled_c:
                    if q["label"] in ("supports", "contradicts"):
                        q["evidence_strength"] = "weak"
                        quotes.append(q)
                self._update_nli_stats(labeled_c, stats)

        # Sort strong first, then supports, then score
        quotes.sort(
            key=lambda x: (
                x.get("evidence_strength", "strong") == "strong",
                x["label"] == "supports",
                float(x.get("score", 0.0)),
            ),
            reverse=True,
        )
        self._log_binding_stats(**stats)
        return quotes[:max_quotes]

    def _expand_concept_aliases(self, concept: str) -> List[str]:
        """Expand concept with 2-3 aliases for better Tier-A matching."""
        concept_lower = concept.lower()
        aliases = [concept]
        
        # Simple alias expansion based on common patterns
        alias_map = {
            'honest': ['honesty', 'truthful', 'truth'],
            'ai': ['artificial intelligence', 'machine learning', 'ml'],
            'alignment': ['aligned', 'safe ai', 'ai safety'],
            'reasoning': ['logic', 'inference', 'rational'],
            'language model': ['llm', 'large language model', 'gpt'],
            'transformer': ['attention', 'neural network', 'deep learning'],
            'sparse autoencoder': ['sae', 'autoencoder', 'sparse coding'],
            'mechanistic interpretability': ['mech interp', 'interpretability', 'explainable ai'],
            'deception': ['lying', 'dishonest', 'misleading'],
            'capability': ['skill', 'ability', 'competence'],
            'oversight': ['supervision', 'monitoring', 'control']
        }
        
        for key, vals in alias_map.items():
            if key in concept_lower:
                aliases.extend([v for v in vals if v not in aliases])
                break
        
        # Add partial matches and plurals
        if not concept.endswith('s') and len(concept) > 4:
            aliases.append(concept + 's')
        if concept.endswith('s') and len(concept) > 4:
            aliases.append(concept[:-1])
            
        return aliases[:3]  # Limit to 3 total

    def _cosine_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        dot_product = np.dot(vec1, vec2)
        norm_a = np.linalg.norm(vec1)
        norm_b = np.linalg.norm(vec2)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot_product / (norm_a * norm_b)

    def _retrieve_tier_a_semantic(self, paper_concept: str, corpus_concept: str, hypothesis: str, k: int) -> List[Dict[str, Any]]:
        """Semantic similarity-based Tier-A retrieval as fallback to lexical."""
        if not self.embedding_model:
            return []
        
        try:
            # Compute embeddings for concepts
            paper_embedding = self.embedding_model.encode(paper_concept)
            corpus_embedding = self.embedding_model.encode(corpus_concept)
            
            candidates = []
            
            # Sample chunks for semantic similarity (limit to prevent memory issues)
            chunk_sample = self.corpus_df.sample(n=min(1000, len(self.corpus_df)), random_state=42)
            
            for idx, chunk in chunk_sample.iterrows():
                chunk_text = str(chunk.get('text', ''))[:500]  # Limit text length
                if len(chunk_text.strip()) < 50:  # Skip very short chunks
                    continue
                    
                # Compute chunk embedding
                chunk_embedding = self.embedding_model.encode(chunk_text)
                
                # Calculate similarity to both concepts
                paper_sim = self._cosine_similarity(paper_embedding, chunk_embedding)
                corpus_sim = self._cosine_similarity(corpus_embedding, chunk_embedding)
                
                # Require moderate similarity to both concepts
                if paper_sim > 0.5 and corpus_sim > 0.5:
                    combined_score = paper_sim * corpus_sim
                    candidates.append({
                        'text': chunk_text,
                        'score': combined_score,
                        'paper_similarity': paper_sim,
                        'corpus_similarity': corpus_sim,
                        'author': chunk.get('author', 'Unknown'),
                        'year': chunk.get('year', 'Unknown'),
                        'doc_id': chunk.get('doc_id', 'Unknown'),
                        'retrieval_tier': 'A-semantic'
                    })
            
            # Sort by combined score and return top-k
            candidates.sort(key=lambda x: x['score'], reverse=True)
            return candidates[:k]
            
        except Exception as e:
            logger.warning(f"Tier-A-Semantic failed: {e}")
            return []

    def _retrieve_tier_a(self, paper_concept: str, corpus_concept: str, hypothesis: str, k: int) -> List[Dict[str, Any]]:
        # Require both concepts present (AND) - use aliases for better matching
        candidates: List[Dict[str, Any]] = []
        
        # Expand both concepts with aliases
        paper_aliases = self._expand_concept_aliases(paper_concept)
        corpus_aliases = self._expand_concept_aliases(corpus_concept)
        
        # Build queries with concept combinations
        queries = []
        for pa in paper_aliases[:2]:  # Top 2 paper aliases
            for ca in corpus_aliases[:2]:  # Top 2 corpus aliases
                queries.append(f"{pa} {ca}")
        queries = list(dict.fromkeys(queries))  # Deduplicate
        
        # Must contain at least one alias from each concept
        must_paper = [t.lower() for t in paper_aliases]
        must_corpus = [t.lower() for t in corpus_aliases]

        for q in queries:
            if not q.strip():
                continue
            part = self._retrieve_chunks_with_filters(
                q, 
                top_k=max(1, k // len(queries)),
                must_contain_paper=must_paper,
                must_contain_corpus=must_corpus,
                phrase_boost=True
            )
            candidates.extend(part)
        result = self._deduplicate_candidates(candidates)[:k]
        
        # If lexical matching fails, try semantic similarity as fallback
        if len(result) == 0 and self.embedding_model:
            semantic_result = self._retrieve_tier_a_semantic(paper_concept, corpus_concept, hypothesis, k)
            if semantic_result:
                return semantic_result
        
        return result

    def _retrieve_tier_b(self, paper_concept: str, corpus_concept: str, hypothesis: str, k: int) -> List[Dict[str, Any]]:
        # Require at least one concept present (OR), add hypothesis head
        candidates: List[Dict[str, Any]] = []
        hyp_head = hypothesis[:100]
        queries = list(dict.fromkeys([f"{paper_concept} {corpus_concept}", paper_concept, corpus_concept, hyp_head]))
        any_terms = [t.lower() for t in [paper_concept, corpus_concept] if t]

        for q in queries:
            if not q.strip():
                continue
            part = self._retrieve_chunks_with_filters(q, top_k=max(1, k // len(queries)),
                                                      must_contain_any=any_terms,
                                                      phrase_boost=False)
            candidates.extend(part)
        return self._deduplicate_candidates(candidates)[:k]

    def _retrieve_tier_c(self, paper_concept: str, corpus_concept: str, hypothesis: str, k: int) -> List[Dict[str, Any]]:
        # No lexical filters; lexical overlap scoring only
        candidates: List[Dict[str, Any]] = []
        queries = list(dict.fromkeys([hypothesis, f"{paper_concept} {corpus_concept}", paper_concept, corpus_concept]))
        for q in queries:
            if not q.strip():
                continue
            part = self._retrieve_chunks(q, top_k=max(1, k // len(queries)))
            candidates.extend(part)
        return self._deduplicate_candidates(candidates)[:k]

    # ----------- retrieval helpers -----------

    def _retrieve_chunks_with_filters(self,
                                      query: str,
                                      top_k: int,
                                      must_contain: Optional[List[str]] = None,
                                      must_contain_any: Optional[List[str]] = None,
                                      must_contain_paper: Optional[List[str]] = None,
                                      must_contain_corpus: Optional[List[str]] = None,
                                      phrase_boost: bool = False) -> List[Dict[str, Any]]:
        if self.corpus_df.empty:
            return []

        base = self._retrieve_chunks(query, top_k=top_k * 3)
        filtered: List[Dict[str, Any]] = []
        must = [t for t in (must_contain or []) if t]
        any_terms = [t for t in (must_contain_any or []) if t]
        paper_aliases = [t.lower() for t in (must_contain_paper or []) if t]
        corpus_aliases = [t.lower() for t in (must_contain_corpus or []) if t]

        for c in base:
            t = c["text"].lower()
            
            # Drop overly long candidates (>3,000 chars) - too long for good NLI
            if len(t) > 3000:
                continue

            # AND filter (original)
            if must and (not all(term in t for term in must)):
                continue

            # OR filter (original)
            if any_terms and (not any(term in t for term in any_terms)):
                continue
            
            # Paper AND Corpus alias filter (for Tier-A)
            if paper_aliases and corpus_aliases:
                has_paper = any(alias in t for alias in paper_aliases)
                has_corpus = any(alias in t for alias in corpus_aliases)
                if not (has_paper and has_corpus):
                    continue

            # Phrase boost (enhanced for alias matching)
            boost_applied = False
            if phrase_boost:
                if must and all(term in t for term in must):
                    c["score"] = float(c.get("score", 0.5)) * 1.5
                    boost_applied = True
                elif paper_aliases and corpus_aliases:
                    has_paper = any(alias in t for alias in paper_aliases)
                    has_corpus = any(alias in t for alias in corpus_aliases)
                    if has_paper and has_corpus:
                        c["score"] = float(c.get("score", 0.5)) * 1.8  # Higher boost for alias matches
                        boost_applied = True

            filtered.append(c)

        filtered.sort(key=lambda x: float(x.get("score", 0.0)), reverse=True)
        return filtered[:top_k]

    def _retrieve_chunks(self, query: str, top_k: int = 20) -> List[Dict[str, Any]]:
        """BM25-lite retrieval with TF-IDF scoring for better relevance."""
        if self.corpus_df.empty:
            return []
        
        import math
        qtokens = [t for t in re.findall(r"\w+", query.lower()) if len(t) >= 3]
        if not qtokens:
            return []

        matches: List[Dict[str, Any]] = []
        scan_cap = min(len(self.corpus_df), self.scan_cap)
        
        # Pre-compute document frequency for IDF calculation
        doc_freq = {}
        N = scan_cap  # Total number of documents
        
        # First pass: calculate document frequencies
        for idx, row in self.corpus_df.iloc[:scan_cap].iterrows():
            text = str(row["text"]).lower()
            tokens = [t for t in re.findall(r"\w+", text) if len(t) >= 3]
            seen_terms = set()
            for term in qtokens:
                if term in tokens and term not in seen_terms:
                    doc_freq[term] = doc_freq.get(term, 0) + 1
                    seen_terms.add(term)
        
        # Second pass: calculate BM25-lite scores
        for idx, row in self.corpus_df.iloc[:scan_cap].iterrows():
            text = str(row["text"]).lower()
            tokens = [t for t in re.findall(r"\w+", text) if len(t) >= 3]
            
            score = 0.0
            for term in qtokens:
                if doc_freq.get(term, 0) == 0:
                    continue
                    
                # Term frequency in document
                tf = sum(1 for t in tokens if t == term)
                if tf == 0:
                    continue
                
                # Inverse document frequency
                idf = math.log((N - doc_freq[term] + 0.5) / (doc_freq[term] + 0.5) + 1)
                
                # BM25-lite score (simplified, no document length normalization)
                score += tf * idf
            
            if score > 0:
                matches.append({
                    "text": row["text"],
                    "author": row.get("author", "Unknown"),
                    "year": row.get("year", 2020),
                    "title": row.get("title", "Untitled"),
                    "doc_id": row.get("doc_id", f"row_{idx}"),
                    "score": float(score),
                })

        matches.sort(key=lambda x: x["score"], reverse=True)
        return matches[:top_k]

    def _deduplicate_candidates(self, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen, uniq = set(), []
        for c in candidates:
            key = (c.get("doc_id", ""), c.get("text", "")[:120])
            if key in seen:
                continue
            seen.add(key)
            uniq.append(c)
        return uniq

    # ----------- NLI labeling -----------

    def _nli_batch_label_with_budget(self,
                                     candidates: List[Dict[str, Any]],
                                     hypothesis: str,
                                     timeout_s: int = 4) -> Tuple[List[Dict[str, Any]], int]:
        """Label candidates with NLI; include fallback + tier stamp through to quotes."""
        labeled: List[Dict[str, Any]] = []
        used_calls = 0

        for c in candidates:
            label = self._nli_label_with_fallback(hypothesis, c["text"], timeout_s)
            nli_method = "nli"  # we don't expose whether fallback used inside; see _lexical_fallback_label

            # minimal quote extraction
            q = self._extract_quote(c["text"])
            labeled.append({
                "source": "corpus",
                "label": label,
                "citation": f"({c.get('author', 'Unknown')}, {c.get('year', 'Unknown')}; {c.get('doc_id', 'Unknown')})",
                "quote": q,
                "score": float(c.get("score", 0.5)),
                "retrieval_tier": c.get("retrieval_tier", "?")
            })
            used_calls += 1
        return labeled, used_calls

    def _truncate_words(self, s: str, n: int) -> str:
        toks = re.findall(r"\w+|\S", s)
        if len(toks) <= n: 
            return s
        out = " ".join(toks[:n])
        return out

    def _clean_quote(self, s: str) -> str:
        # strip urls/page headers/boilerplate that explode tokens
        s = re.sub(r'https?://\S+', '', s)
        s = re.sub(r'Page \d+[: ]', '', s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    def _nli_label_with_fallback(self, claim_text: str, quote: str, timeout_s: int = 4) -> str:
        """Ask local LLM for NLI label; on error or junk, use lexical fallback."""
        # Critical: truncate inputs to prevent context overflow
        claim = self._truncate_words(claim_text, 80)   # keep claim short & focused
        quote = self._clean_quote(self._truncate_words(quote, 120))  # 100–120 tokens max
        
        system_prompt = (
            "Label the relationship between the QUOTE and the CLAIM.\n\n"
            "Return exactly one word:\n"
            '- "supports" if the quote provides evidence supporting the claim\n'
            '- "contradicts" if the quote provides evidence against the claim\n'
            '- "neutral" if neither\n'
        )
        user_prompt = f"CLAIM: {claim}\n\nQUOTE: {quote}\n\nRelationship:"

        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.1,
                max_tokens=16,
                timeout=timeout_s
            )
            content = (resp.choices[0].message.content or "").strip().lower()
            if content in ("supports", "contradicts", "neutral"):
                return content
            if "support" in content:
                return "supports"
            if "contradict" in content:
                return "contradicts"
            return "neutral"
        except Exception as e:
            print(f"NLI timeout/error ({timeout_s}s): {e}")
            return self._lexical_fallback_label(claim_text, quote)

    def _lexical_fallback_label(self, claim_text: str, quote: str) -> str:
        """Heuristic label if LLM/NLI is unavailable/unreliable."""
        ql = quote.lower()
        contra = [" not ", "fails", "unable", "contradict", "however", " but ", " although ", " nevertheless ",
                  " despite ", " except ", " unless ", "wrong", "incorrect", "false"]
        if any(w in ql for w in contra):
            return "contradicts"
        supp = [" show", " evidence", " support", "consistent", " replicate", " confirm", " validate",
                " demonstrate", " prove", " establish", " indicate", " suggest"]
        if any(w in ql for w in supp):
            return "supports"
        return "neutral"

    def _update_nli_stats(self, labeled_quotes: List[Dict[str, Any]], stats: Dict[str, int]):
        for q in labeled_quotes:
            lab = q.get("label", "neutral")
            if lab == "supports":
                stats["supports"] += 1
            elif lab == "contradicts":
                stats["contradicts"] += 1
            elif lab == "neutral":
                stats["neutrals"] += 1
            else:
                stats["nli_fails"] += 1

    def _log_binding_stats(self, tierA: int, tierB: int, tierC: int,
                           supports: int, contradicts: int, neutrals: int, nli_fails: int):
        print(f"[Binder] tierA:{tierA} | tierB:{tierB} | tierC:{tierC} | "
              f"supports:{supports} opposes:{contradicts} neutrals:{neutrals} | nli_fail:{nli_fails}")

    # ----------- utilities -----------

    def _extract_quote(self, text: str) -> str:
        """Take a well‑formed sentence or merge short ones to ~max_quote_length."""
        sents = self._split_into_sentences(text)
        if not sents:
            return text[: self.max_quote_length].strip()
        for s in sents:
            if self.min_quote_length <= len(s) <= self.max_quote_length:
                return s.strip()
        combined = ""
        for s in sents:
            if len((combined + " " + s).strip()) <= self.max_quote_length:
                combined = (combined + " " + s).strip()
            else:
                break
        if len(combined) >= self.min_quote_length:
            return combined
        return text[: self.max_quote_length].strip()

    def _split_into_sentences(self, text: str) -> List[str]:
        # Simple sentence splitter
        parts = re.split(r"[.!?]+", text)
        return [p.strip() for p in parts if p.strip()]

    def _has_required_evidence(self, evidence: List[Dict[str, Any]]) -> bool:
        paper_q = [e for e in evidence if e.get("source") == "paper"]
        corpus_q = [e for e in evidence if e.get("source") == "corpus"]
        return len(paper_q) >= 1 and len(corpus_q) >= 1

    def _generate_theme_hint(self, daydream: Dict[str, Any]) -> str:
        pc = (daydream.get("paper_concept") or "").strip()
        cc = (daydream.get("corpus_concept") or "").strip()
        if pc and cc:
            return f"{pc} & {cc}"
        return pc or cc or "General"

    def _update_heartbeat(self, pair_idx: int, tier: str, kept: int):
        """Write a small JSON heartbeat approximately every 5 seconds."""
        now = time.time()
        last = getattr(self, "last_heartbeat", 0.0) or 0.0
        if now - last < 5:
            return
        payload = {"ts": now, "pair_idx": pair_idx, "stage": tier, "kept": kept, "files_loaded": self.files_loaded}
        try:
            with open(self.heartbeat_file, "w", encoding="utf-8") as f:
                json.dump(payload, f)
            self.last_heartbeat = now
        except Exception:
            # don't crash on heartbeat
            pass


# ----------- local smoke test -----------

if __name__ == "__main__":
    binder = DDLEvidenceBinder("chunked_corpus/")
    # Mock daydream
    d = {
        "paper_concept": "sparse autoencoder",
        "corpus_concept": "attention mechanism",
        "hypothesis": "Sparse autoencoders could be combined with attention mechanisms to expose and manipulate structured feature directions that mediate control tokens.",
        "paper_anchor": "sparse autoencoder",
    }
    paper = "Sparse autoencoders learn compressed representations by forcing most neurons to be inactive, creating interpretable features that can steer model behavior in controlled ways."

    ev = binder._bind_single_daydream(d, paper)
    print(f"Found {len(ev)} evidence items")
    for e in ev:
        print(f"- {e['source']} ({e.get('label','?')} | {e.get('retrieval_tier','paper')}): {e['quote'][:80]}...")
